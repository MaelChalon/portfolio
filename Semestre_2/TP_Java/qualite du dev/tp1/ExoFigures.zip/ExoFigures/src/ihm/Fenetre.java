/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ihm;

import exofigures.Carre;
import exofigures.Cercle;
import exofigures.Figure;
import exofigures.Figure2D;
import exofigures.Parallelepipede;
import exofigures.Rectangle;
import exofigures.Segment;
import exofigures.Sphere;
import exofigures.Triangle;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Eric-PC
 */
public class Fenetre extends JFrame implements ActionListener {

    JComboBox combo = new JComboBox();
    JLabel lblcombo = new JLabel("Choix de la figure");
    JTextField tdim1, tdim2, tdim3, trayon;
    JLabel lbl1, lbl2, lbl3, lblray;
    JLabel lblperim, lblsurface, lblvolume;
    JButton butperim, butsurface, butvolume;

    public Fenetre() {
        this.setTitle("MaFenetre");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        tdim1 = new JTextField(10);
        tdim2 = new JTextField(10);
        tdim3 = new JTextField(10);
        trayon = new JTextField(10);

        butperim = new JButton("Perimetre:");
        butsurface = new JButton("Surface:");
        butvolume = new JButton("Volume:");
        butperim.addActionListener(this);
        butsurface.addActionListener(this);
        butvolume.addActionListener(this);

        lblperim = new JLabel();
        lblsurface = new JLabel();
        lblvolume = new JLabel();
        lbl1 = new JLabel("Dimension 1");
        lbl2 = new JLabel("Dimension 2");
        lbl3 = new JLabel("Dimension 3");
        lblray = new JLabel("Rayon");

        combo.addItem("Segment");
        combo.addItem("Rectangle");
        combo.addItem("Carre");
        combo.addItem("Triangle");
        combo.addItem("Cercle");
        combo.addItem("Parallelepipede");
        combo.addItem("Sphere");

        placement();

        this.setVisible(true);

    }

    public void placement() {
        JPanel pano = new JPanel();
        pano.setLayout(new GridBagLayout());
        GridBagConstraints cont = new GridBagConstraints();

        cont.fill = GridBagConstraints.BOTH;
        cont.insets = new Insets(10, 10, 10, 10);
        cont.gridx = 0;
        cont.gridy = 0;
        cont.gridwidth = 1;
        pano.add(lblcombo, cont);

        cont.gridx = 1;
        cont.gridwidth = 2;
        pano.add(combo, cont);

        cont.gridy = 1;
        cont.gridx = 0;
        cont.gridwidth = 1;
        pano.add(lbl1, cont);

        cont.gridx = 1;
        pano.add(lbl2, cont);

        cont.gridx = 2;
        pano.add(lbl3, cont);

        cont.gridx = 3;
        pano.add(lblray, cont);
        cont.insets = new Insets(0, 0, 0, 0);
        cont.gridy = 2;
        cont.gridx = 0;
        pano.add(tdim1, cont);
        cont.gridx = 1;
        pano.add(tdim2, cont);
        cont.gridx = 2;
        pano.add(tdim3, cont);
        cont.gridx = 3;
        pano.add(trayon, cont);
        cont.insets = new Insets(10, 10, 10, 10);
        cont.gridy = 3;
        cont.gridx = 0;
        pano.add(butperim, cont);
        cont.gridx = 1;
        pano.add(lblperim, cont);
        cont.gridy++;
        cont.gridx = 0;
        pano.add(butsurface, cont);
        cont.gridx = 1;
        pano.add(lblsurface, cont);
        cont.gridy++;
        cont.gridx = 0;
        pano.add(butvolume, cont);
        cont.gridx = 1;
        pano.add(lblvolume, cont);

        this.setContentPane(pano);
        this.pack();
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        double dim1, dim2, dim3, rayon;
        String type = (String) combo.getSelectedItem();
        Figure figure = null;

        if (type.compareTo("Rectangle") == 0) {
            dim1 = Double.parseDouble(tdim1.getText());
            dim2 = Double.parseDouble(tdim2.getText());
            figure = new Rectangle(dim1, dim2);
        } else if (type.compareTo("Carre") == 0) {
            dim1 = Double.parseDouble(tdim1.getText());
            figure = new Carre(dim1);
        } else if (type.compareTo("Triangle") == 0) {
            dim1 = Double.parseDouble(tdim1.getText());
            dim2 = Double.parseDouble(tdim2.getText());
            dim3 = Double.parseDouble(tdim3.getText());
            figure = new Triangle(dim1, dim2, dim3);
        } else if (type.compareTo("Cercle") == 0) {
            rayon = Double.parseDouble(trayon.getText());
            figure = new Cercle(rayon);
        } else if (type.compareTo("Segment") == 0) {
            dim1 = Double.parseDouble(tdim1.getText());
            figure = new Segment(dim1);
        } else if (type.compareTo("Sphere") == 0) {
            rayon = Double.parseDouble(trayon.getText());
            figure = new Sphere(rayon);
        } else if (type.compareTo("Parallelepipede") == 0) {
            dim1 = Double.parseDouble(tdim1.getText());
            dim2 = Double.parseDouble(tdim2.getText());
            dim3 = Double.parseDouble(tdim3.getText());
            figure = new Parallelepipede(dim1, dim2, dim3);
        }

        if (ae.getSource() == butperim) {
            lblperim.setText(((Figure2D) figure).calculPerimetre() + "");
        } else if (ae.getSource() == butsurface) {
            //a completer    
            lblsurface.setText(((Figure2D) figure).calculSurface() + "");
        } else if (ae.getSource() == butvolume) {
            //a completer
        }
    }

}
