/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package exofigures;

/**
 *
 * @author Effantin
 */
public class Carre extends Rectangle{

    public Carre(double cote) {
        super(cote,cote);
    }

}
