/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package exofigures;

/**
 *
 * @author Effantin
 */
public class Rectangle extends Figure2D{
    public double largeur, longueur;

    public Rectangle(double largeur, double longueur) {

        this.largeur = largeur;
        this.longueur = longueur;
    }

    @Override
    public double calculPerimetre() {
        return 2*(longueur+largeur);
    }

    @Override
    public boolean isSymetric() {
        return true;
    }

    public double calculSurface() {
        return longueur*largeur;
    }



}
