/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package exofigures;

/**
 *
 * @author Effantin
 */
public class Parallelepipede extends Figure3D {

    public double largeur, longueur, hauteur;

    public Parallelepipede(double largeur, double longueur, double hauteur) {
        this.largeur = largeur;
        this.longueur = longueur;
        this.hauteur = hauteur;
    }

    @Override
    public double calculVolume() {
        return longueur * largeur * hauteur;
    }

    @Override
    public boolean isSymetric() {
        return true;
    }

    public double calculSurface() {
        return 2.0 * (largeur * longueur + largeur * hauteur + longueur * hauteur);
    }
}
