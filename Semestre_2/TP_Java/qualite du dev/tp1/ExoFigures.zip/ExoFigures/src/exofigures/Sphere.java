/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package exofigures;

/**
 *
 * @author Effantin
 */
public class Sphere extends Figure3D {

    public double rayon;

    public Sphere(double rayon) {
        this.rayon = rayon;
    }

    @Override
    public double calculVolume() {
        return 4.0 * Math.PI * rayon * rayon * rayon / 3.0;
    }

    @Override
    public boolean isSymetric() {
        return true;
    }

    public double calculSurface() {
        return 4.0 * Math.PI * rayon * rayon;
    }
}
