/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package exofigures;

/**
 *
 * @author Effantin
 */
public class Cercle extends Figure2D{
    public double rayon;

    public Cercle(double rayon) {
        
        this.rayon = rayon;
    } 
    @Override
    public boolean isSymetric() {
        return true;
    }

    public double calculSurface() {
        return Math.PI*rayon*rayon;
    }

    @Override
    public double calculPerimetre() {
        return 2.0*Math.PI*rayon;//change body of generated methods, choose Tools | Templates.
    }

}
