/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package exofigures;

/**
 *
 * @author Effantin
 */
public class Triangle extends Figure2D{
    public double cote1,cote2,cote3;

    public Triangle(double cote1, double cote2, double cote3) {
        this.cote1 = cote1;
        this.cote2 = cote2;
        this.cote3 = cote3;
    }

    @Override
    public double calculPerimetre() {
        return cote1+cote2+cote3;
    }

    @Override
    public boolean isSymetric() {
        if(cote1==cote2 || cote2==cote3 || cote3==cote1)
            return true;
        return false;
    }

    public double calculSurface() {
        double p=calculPerimetre()/2.0;
        return (Math.sqrt(p*(p-cote1)*(p-cote2)*(p-cote3)));
    }


}
