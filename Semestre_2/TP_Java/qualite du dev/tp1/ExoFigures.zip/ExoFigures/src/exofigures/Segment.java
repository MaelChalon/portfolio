/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package exofigures;

/**
 *
 * @author Effantin
 */
public class Segment extends Figure{
    public double longueur;

    public Segment(double longueur) {
        this.longueur = longueur;
    }

    @Override
    public boolean isSymetric() {
        return true;
    }

    public double longueur(){
        return longueur;
    }

}
