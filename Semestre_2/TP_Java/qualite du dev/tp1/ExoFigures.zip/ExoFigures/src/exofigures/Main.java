/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package exofigures;

import ihm.Fenetre;

/**
 *
 * @author Effantin
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Figure t[]=new Figure[8];
        t[0]=new Segment( 5.2);
        t[1]=new Rectangle( 5.2, 6.3);
        t[2]=new Cercle( 3.4);
        t[3]=new Parallelepipede( 5.3, 6.1, 1.8);
        t[4]=new Carre(4.4);
        t[5]=new Sphere(3.0);
        t[6]=new Triangle(1.2,2.1,3.2);
        t[7]=new Triangle(2.2,2.2,3.3);

        //affichage des données
        String s;
        for(int i=0;i<t.length;i++){
            s=":\nAxe de symétrie: "+t[i].isSymetric()+"\n";
            //infos spécifiques aux figures
            if(t[i] instanceof Segment)
                s+="Longueur: "+((Segment)t[i]).longueur()+"\n";
            //infos spécifiques aux figures 2D
            if(t[i] instanceof Figure2D){
                s+="Perimetre: "+((Figure2D)t[i]).calculPerimetre()+"\n";
            }
            //infos spécifiques aux figures 3D
            if(t[i] instanceof Figure3D){
                s+="Volume: "+((Figure3D)t[i]).calculVolume()+"\n";
            }
            //infos spécifiques aux interfaces
            if(t[i] instanceof Surface){
                s+="Surface: "+((Surface)t[i]).calculSurface()+"\n";
            }
            System.out.println(s);
        }
        
        Fenetre fen=new Fenetre();

    }

}
