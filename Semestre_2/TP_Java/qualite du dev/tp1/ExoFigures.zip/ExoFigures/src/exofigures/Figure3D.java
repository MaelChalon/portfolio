/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package exofigures;

/**
 *
 * @author Effantin
 */
public abstract class Figure3D extends Figure implements Surface,Volume {

    

}
