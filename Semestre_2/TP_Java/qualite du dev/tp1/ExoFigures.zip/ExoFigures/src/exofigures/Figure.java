/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package exofigures;

/**
 *
 * @author Effantin
 */
public abstract class Figure {

   
    public abstract boolean isSymetric();
}
