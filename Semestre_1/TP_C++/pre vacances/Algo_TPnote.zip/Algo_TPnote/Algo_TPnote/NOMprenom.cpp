#include<iostream>
#include"data.h"
using namespace std;



int main() {


	return 0;
}