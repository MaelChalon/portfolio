#include<iostream>

using namespace std;

int main() {

	int u0, un;
	int i = 0;
	int tpsVol, tpsVolAltitude, altMax;

	tpsVol = 0;
	tpsVolAltitude = 0;
	altMax = 0;

	//saisie de la valeur initiale
	cout << "Donner la valeur initiale: ";
	cin >> u0;
	cout << "u0 = " << u0 << endl;

	//parcours des diff�rents �l�ments de la suite
	un = u0;
	while (un != 1) {
		/***** partie 1 *****/
		i++;
		if (un % 2 == 0)
			un = un / 2;
		if (un % 2 == 1)
			un = 3 * un + 1;
		cout << "u" << i << " = " << un << endl;
		/***** partie 2 *****/
		if (un <= u0)
			tpsVolAltitude = i - 1;
		if (un > u0)
			altMax = un;
	}
	tpsVol = i;

	cout << "Temps de vol: " << tpsVol << endl;
	cout << "Temps de vol en altitude: " << tpsVolAltitude << endl;
	cout << "Altitude max: " << altMax << endl;
	return 0;
}